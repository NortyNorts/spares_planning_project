package com.codeclan.com.SparesPlanning;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SparesPlanningApplication {

	public static void main(String[] args) {
		SpringApplication.run(SparesPlanningApplication.class, args);
	}

}
