package com.codeclan.com.SparesPlanning;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SparesPlanningApplicationTests {

	@Test
	void contextLoads() {
	}

}
